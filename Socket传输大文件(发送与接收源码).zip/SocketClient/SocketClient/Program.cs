﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Windows.Forms;


namespace SocketClient
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            SocketClient();
        }
        public static string serverIp = "127.0.0.1";//设置服务端IP
        public static int serverPort = 8888;//服务端端口
        public static Socket socketClient;//定义socket
        public static Thread threadClient;//定义线程
        public static byte[] result = new byte[1024];//定义缓存
        public static void SocketClient()
        {
            socketClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);//创建一个socket的对象
            IPAddress ip = IPAddress.Parse(serverIp);//获取服务器IP地址
            IPEndPoint point = new IPEndPoint(ip, serverPort);//获取端口
            try
            {
                socketClient.Connect(point);//链接服务器IP与端口
                Console.WriteLine("连接服务器中.....");

            }
            catch (Exception)
            {
                Console.WriteLine("与服务器链接失败！！！");
                return;
            }
            Console.WriteLine("与服务器链接成功！！！");
            try
            {
                Thread.Sleep(1000);    //等待1秒钟  
                //通过 socketClient 向服务器发送数据
                string sendMessage = "已成功接到SocketClient发送的消息";//发送到服务端的内容
                byte[] send = Encoding.UTF8.GetBytes(sendMessage);//Encoding.UTF8.GetBytes()将要发送的字符串转换成UTF8字节数组
                byte[] SendMsg = new byte[send.Length + 1];//定义新的字节数组
                SendMsg[0] = 0;//将数组第一位设置为0，来表示发送的是消息数据  
                Buffer.BlockCopy(send, 0, SendMsg, 1, send.Length);//偏移复制字节数组
                socketClient.Send(SendMsg);  //将接受成功的消息返回给SocketServer服务器 
                Console.WriteLine("发送完毕：{0}", sendMessage);

            }                                                                                                                     
            catch
            {
                socketClient.Shutdown(SocketShutdown.Both);//禁止Socket上的发送和接受
                socketClient.Close();//关闭Socket并释放资源
            }
            //打开文件
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "选择要传的文件";
            ofd.InitialDirectory = @"D:\project";
            //ofd.Filter = "文本文件|*.txt|图片文件|*.jpg|视频文件|*.avi|所有文件|*.*";
            ofd.ShowDialog();
            //得到选择文件的路径
            string filePath = ofd.FileName;//获取文件的完整路径
            Console.WriteLine("发送的文件路径为："+filePath);
            using (FileStream fsRead = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Read))
            {
                //1. 第一步：发送一个文件，表示文件名和长度，让客户端知道后续要接收几个包来重新组织成一个文件
                string fileName = Path.GetFileName(filePath);
                Console.WriteLine("发送的文件名是：" + fileName);
                long fileLength = fsRead.Length;//文件长度
                Console.WriteLine("发送的文件长度为："+fileLength);
                string totalMsg = string.Format("{0}-{1}", fileName, fileLength);
                byte[] buffer = Encoding.UTF8.GetBytes(totalMsg); 
                byte[] newBuffer = new byte[buffer.Length + 1];
                newBuffer[0] = 2;
                Buffer.BlockCopy(buffer, 0, newBuffer, 1, buffer.Length);
                socketClient.Send(newBuffer);//发送文件前，将文件名和长度发过去
                //2第二步：每次发送一个1MB的包，如果文件较大，则会拆分为多个包
                byte[] Filebuffer = new byte[1024 * 1024 * 5];//定义1MB的缓存空间
                int readLength = 0;  //定义读取的长度
                bool firstRead = true;
                long sentFileLength = 0;//定义发送的长度
                while ((readLength = fsRead.Read(buffer, 0, buffer.Length)) > 0 && sentFileLength < fileLength)
                {
                    sentFileLength += readLength;
                    //第一次发送的字节流上加个前缀1
                    if (firstRead)
                    {
                        byte[] firstBuffer = new byte[readLength + 1];
                        firstBuffer[0] = 1;//标记1，代表为文件
                        Buffer.BlockCopy(buffer, 0, firstBuffer, 1, readLength);
                        socketClient.Send(firstBuffer, 0, readLength + 1, SocketFlags.None);
                        Console.WriteLine("第一次读取数据成功，在前面添加一个标记");
                        firstRead = false;
                        continue;
                    }
                    socketClient.Send(buffer, 0, readLength, SocketFlags.None);
                    Console.WriteLine("{0}: 已发送数据：{1}/{2}", socketClient.RemoteEndPoint, sentFileLength, fileLength);
                }
                fsRead.Close();
                Console.WriteLine("发送完成");
            }
            Console.ReadLine();
        }
    }

}
